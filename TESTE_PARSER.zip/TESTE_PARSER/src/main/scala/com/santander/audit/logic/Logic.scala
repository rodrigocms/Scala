/* package com.santander.audit.logic

import com.santander.audit.configuration.{Configuration, ConfigurationException}
import com.santander.audit.util.Delta
import com.typesafe.scalalogging.LazyLogging
import org.apache.hadoop.security.UserGroupInformation
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql
import org.apache.spark.sql._
import org.apache.spark.sql.functions.{col, lit}

import scala.util.{Failure, Success}

object Logic extends LazyLogging {
  var sparkSession: SparkSession = _
  var configuration: Configuration = _
  var broadcastConfiguration: Broadcast[Configuration] = _
  var anomalies_descriptions: Map[Int, String] = Map()

  def init(): Unit = {
    sparkSession = SparkSession.builder().enableHiveSupport().getOrCreate()
    configuration = getConfiguration()
    broadcastConfiguration = sparkSession.sparkContext.broadcast(configuration)
    sparkSession.sparkContext.setCheckpointDir(s"/tmp/${UserGroupInformation.getCurrentUser.getShortUserName}")
    getAnomaliesDescriptions()
  }

  def getConfiguration(): Configuration = {
    Configuration.apply match {
      case Success(value) =>
        logger.info(s"Configuration successfully created: ${value.toString}")
        value
      case Failure(exception) =>
        throw ConfigurationException.apply(s"Invalid configuration: ",
          exception)
    }
  }

  def getAnomaliesDescriptions(): Unit = {
    sparkSession.read
      .table(configuration.anomalies_descriptions)
      .collect()
      .foreach(row => anomalies_descriptions += (row(0).asInstanceOf[Int] -> row(1).asInstanceOf[String]))
  }

  def getDifferentPartitions(source_table: String, dest_table: String, delta_col: String): sql.DataFrame = {
    Delta.getDifferentPartitions(sparkSession, source_table, dest_table, delta_col)
  }

  private def saveTable(table: sql.DataFrame, deltaColumns: Seq[String], save_mode: SaveMode, destination: String): Unit = {
    table.write
      .partitionBy(deltaColumns: _*)
      .mode(save_mode)
      .format("parquet")
      .saveAsTable(destination)
  }

  def insertIntoTable(table: sql.DataFrame, deltaColumns: Seq[String], destination: String): Unit = {
    if(table.sparkSession.catalog.tableExists(destination)){
      val oldConf = table.sparkSession.conf.get("spark.sql.sources.partitionOverwriteMode")
      table.sparkSession.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")

      table.write
        .mode(SaveMode.Overwrite)
        .format("parquet")
        .insertInto(destination)

      table.sparkSession.conf.set("spark.sql.sources.partitionOverwriteMode", oldConf)
    }
    else
      saveTable(table, deltaColumns, SaveMode.Overwrite, destination)
  }


  def getTableIFRS9_CLI_MOR(analysisPeriod: Dataset[Row]): sql.DataFrame = {
    val ifrs9_cli_mor_analysis_period_df = sparkSession.read.table(configuration.ifrs9_cli_mor_origin_table)
      .join(analysisPeriod, "data_date_part")

    ifrs9_cli_mor_analysis_period_df.createOrReplaceTempView("ifrs9_cli_mor_analysis")

    val ifrs9_cli_mor_alert1 = sparkSession.sql(
      s"""SELECT ccliente, cgestor, cstatus, cdata_status, cutilizador, dcarregamento, data_date_part
         |FROM ifrs9_cli_mor_analysis
         |WHERE from_unixtime(unix_timestamp(cdata_status, 'yyyy-MM-dd HH:mm:ss'), 'HH:mm') > '21:00'
         |OR from_unixtime(unix_timestamp(cdata_status, 'yyyy-MM-dd HH:mm:ss'), 'HH:mm') < '07:00'""".stripMargin
    ).withColumn(
      "anomaly_type", lit(14)
    ).withColumn(
      "anomaly_description", lit(anomalies_descriptions(14))
    )


    val yesterday= java.time.LocalDate.now.minusDays(1).toString

    val ifrs9_cli_mor_alert2 = sparkSession.sql(
      s"""SELECT cutilizador, count(*) AS counts, data_date_part
         |FROM ifrs9_cli_mor_analysis
         |WHERE data_date_part = ${yesterday} and cdata_status = ${yesterday}
         |group by cutilizador, data_date_part
         |having count(*) > ${configuration.ifrs9_cli_mor_exec_limit}
         |""".stripMargin
    ).withColumn(
      "anomaly_type", lit(25)
    ).withColumn(
      "anomaly_description", lit(s"Foi detectado um número elevado de intervenções " +
        s"(mais de ${configuration.ifrs9_cli_mor_exec_limit})")
    )

    val ifrs9_cli_mor_alerts1_cols = ifrs9_cli_mor_alert1.columns.toSet
    val ifrs9_cli_mor_alerts2_cols = ifrs9_cli_mor_alert2.columns.toSet
    val ifrs9_cli_mor_total_cols = ifrs9_cli_mor_alerts1_cols ++ ifrs9_cli_mor_alerts2_cols

    val reorderedColumnNames = Array("ccliente", "cgestor", "cstatus",
      "cdata_status", "cutilizador","dcarregamento", "counts",
      "anomaly_type", "anomaly_description","data_date_part")

    val ifrs9_cli_mor_alerts = ifrs9_cli_mor_alert1
      .select(unionDiffCols(ifrs9_cli_mor_alerts1_cols, ifrs9_cli_mor_total_cols):_*)
      .union(ifrs9_cli_mor_alert2.select(unionDiffCols(ifrs9_cli_mor_alerts2_cols, ifrs9_cli_mor_total_cols):_*))
      .select(reorderedColumnNames.head, reorderedColumnNames.tail: _*)


    insertEmptyPartitions(ifrs9_cli_mor_alerts, analysisPeriod, configuration.ifrs9_cli_mor_anomalies_table)

    ifrs9_cli_mor_alerts
  }


  def insertEmptyPartitions(alerts_table:Dataset[Row], analysisPeriod:Dataset[Row], anomaliesTable: String): Unit = {

    //val alerts_dates = alerts_table.select("data_date_part").distinct()
    val alerts_dates = alerts_table.select("data_date_part").distinct().collect().map(r => r(0).toString)
    val analysisperiod_dates = analysisPeriod.select("data_date_part").distinct().collect().map(r => r(0).toString)
    val partitions_without_alerts = alerts_dates.intersect(analysisperiod_dates)

    //val partitions_without_alerts = analysisPeriod
    //  .join(alerts_dates, alerts_dates("data_date_part") === analysisPeriod("data_date_part"), "left_anti")


    //if dataframe is not empty then save the info that some partitions have no alerts in the anomalies table
    if (!partitions_without_alerts.isEmpty) {
      //if table anomalies_table does not exists create it
      if (!Delta.tableExists(sparkSession, anomaliesTable)) {
        val empty_anomalies = sparkSession.createDataFrame(sparkSession.sparkContext.emptyRDD[Row], alerts_table.schema)
        empty_anomalies.write.format("parquet").partitionBy("data_date_part")
          .saveAsTable(anomaliesTable)
      }
      //fill the no anomalies rows in the right partitions

      partitions_without_alerts
        .foreach(date => {
          logger.info(s">>>Insert on table ${anomaliesTable} empty partition ${date.toString}")
          sparkSession.sql(
            s"""
               |insert into table ${anomaliesTable}
               | partition(data_date_part='${date.toString}')
               | values(${"null," * (alerts_table.columns.length - 2)}'Sem anomalias detetadas nesta partição')
               |""".stripMargin
          )
        })
    }
  }


  def makeReport(anomaliesDataFrame: Dataset[Row]): String = {
    val report = anomaliesDataFrame
      .groupBy("data_date_part", "anomaly_type", "anomaly_description")
      .count()
      .toJSON
      .collect()
      .mkString("[", ",", "]")

    report
  }


  def unionDiffCols(myCols: Set[String], allCols: Set[String]): Seq[Column] = allCols.toList.map {
    case x if myCols.contains(x) => col(x)
    case x => lit(null).as(x)
  }

}
case class RangeModel (val data_date_part : String)

*/