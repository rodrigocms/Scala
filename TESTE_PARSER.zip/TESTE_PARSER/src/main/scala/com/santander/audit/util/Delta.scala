/*package com.santander.audit.util

import com.typesafe.scalalogging.LazyLogging
import org.apache.spark.sql.catalyst.TableIdentifier
import org.apache.spark.sql.functions.{col, lit}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

import scala.util.Try

object Delta extends LazyLogging {


  def tableExists(spark: SparkSession, table_name: String): Boolean = {
    spark.sessionState.catalog.tableExists(demultiplex(table_name))
  }

  def computeDelta(spark: SparkSession,
                   source: String,
                   destination: String,
                   deltaColumns: String*): DataFrame = {

    if (!spark.sessionState.catalog.tableExists(demultiplex(destination))) {
      logger.info(
        s"Destination table $destination does not exist. Delta is equal to full table $source content.")
      spark.read.table(source)
    } else {
      Try {
        logger.info("Trying to run delta partitions.")
        deltaPartitions(spark, demultiplex(source), demultiplex(destination))
      } getOrElse {
        logger.info("Couldnt run delta partitions.")
        val sourceTable = spark.read.table(source)
        val destinationTable = spark.read.table(destination)
        val diff = sourceTable
          .select(deltaColumns map col: _*)
          .except(destinationTable.select(deltaColumns map col: _*))
          .dropDuplicates()
        sourceTable.join(diff, deltaColumns)
      }
    }
  }

  def deltaPartitions(sparkSession: SparkSession,
                      source: TableIdentifier,
                      target: TableIdentifier): DataFrame = {
    val catalog = sparkSession.sessionState.catalog
    val sourceData = sparkSession.read.table(qualifiedName(source))
    val sourcePartitionSchema = catalog.getTableMetadata(source).partitionSchema
    val targetPartitionSchema = catalog.getTableMetadata(target).partitionSchema
    assert(
      sourcePartitionSchema.equals(targetPartitionSchema),
      s"Partition schema does not match.\nSource partition schema: ${sourcePartitionSchema.prettyJson}\nTarget partition schema: ${targetPartitionSchema.prettyJson}"
    )
    assert(
      sourcePartitionSchema.nonEmpty,
      "Provided tables are not partitioned. Cannot compute partition delta.")
    val partitionsToLoad = catalog
      .listPartitions(source)
      .map(_.spec)
      .diff(catalog.listPartitions(target).map(_.spec))
    logger.info(s"Partitions to load: ${partitionsToLoad.mkString("\n")}")
    if(partitionsToLoad.nonEmpty){
      val condition = partitionsToLoad map { partitionSpec => {
        partitionSpec map { case (k, v) => col(k) === lit(v) } reduce {
          _ and _
        }
      }
      } reduce {
        _ or _
      }
      val a = sourceData.where(condition)
      logger.info("QUERY: " + a.queryExecution.simpleString)
      a
    }
    else {
      logger.info("partitionsToLoad is empty")
      sparkSession.createDataFrame(sparkSession.sparkContext
        .emptyRDD[Row], catalog.getTableMetadata(source).schema)
    }
  }

  def getDifferentPartitions(spark: SparkSession, source_table: String, dest_table: String, delta_col: String): DataFrame = {
    if (!spark.sessionState.catalog.tableExists(demultiplex(source_table))) {
      throw new RuntimeException(">>>No source table " + source_table)
    } else {
      if (dest_table != "" || !dest_table.isEmpty) {
        if (!spark.sessionState.catalog.tableExists(demultiplex(dest_table))) {
          logger.info(s">>>Destiny table ${dest_table} does not exists so will get all partitions from ${source_table}")
          val partitions = getPartitionsToStringArray(spark.sql(s"show partitions ${source_table}"))

          import spark.implicits._
          partitions.toSeq.toDF(delta_col)
        } else {
          diffPartitions(spark, source_table, dest_table, delta_col)
        }
      } else {
        throw new RuntimeException(">>>No target table for  " + source_table)
      }
    }

  }

  private def diffPartitions(spark: SparkSession, source_table: String, dest_table: String, delta_col: String): DataFrame = {
    val partitions_ori = getPartitionsToStringArray(spark.sql(s"show partitions ${source_table}"))

    val partitions_dest = getPartitionsToStringArray(spark.sql(s"show partitions ${dest_table}"))

    import spark.implicits._

    val df_ori = partitions_ori.toSeq.toDF(delta_col)

    val df_dest = partitions_dest.toSeq.toDF(delta_col)

    val result = df_ori.join(df_dest, df_ori(delta_col) === df_dest(delta_col), "left_anti").distinct()

    result

  }

  def getPartitionsToStringArray(dataFrame: DataFrame): Array[String] = {
    dataFrame.collect()
      .map(row =>
        row(0).asInstanceOf[String]
          .split("/")(0)
          .split("=")(1)
      )
  }

  private def qualifiedName(tableIdentifier: TableIdentifier) =
    s"${tableIdentifier.database.fold("")(database => s"$database.")}${tableIdentifier.table}"

  def demultiplex(table: String): TableIdentifier =
    Try {
      val demultiplexed = table.split("\\.", -1)
      TableIdentifier.apply(demultiplexed.apply(1),
        Some(demultiplexed.apply(0)))
    }.getOrElse(TableIdentifier.apply(table))
}

 */