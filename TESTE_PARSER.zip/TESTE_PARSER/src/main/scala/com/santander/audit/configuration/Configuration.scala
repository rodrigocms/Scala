/* package com.santander.audit.configuration

import com.typesafe.config.{ConfigFactory, ConfigParseOptions}

import scala.collection.JavaConverters._
import scala.util.Try

object Configuration {
  val cluster = "audit.auxiliary.cluster"
  val anomalies_descriptions = "audit.auxiliary.anomalies_descriptions"

  val ifrs9_cli_mor_origin_table="audit.auxiliary.ifrs9_cli_mor_origin_table"
  val ifrs9_cli_mor_exec_limit = "audit.auxiliary.ifrs9_cli_mor_exec_limit"

  val ifrs9_cli_mor_anomalies_table = "audit.report.anomalies_tables.ifrs9_cli_mor"

  val emailProvider = "audit.report.email.provider"
  val emailDestinations = "audit.report.email.to"
  val emailSecurityProvider = "audit.report.email.security.provider"
  val emailSecurityGrantType = "audit.report.email.security.grantType"
  val emailSecurityClientId = "audit.report.email.security.clientId"
  val emailSecurityClientSecret = "audit.report.email.security.clientSecret"
  val smsProvider = "audit.report.sms.provider"
  val smsDestinations = "audit.report.sms.to"

  def apply: Try[Configuration] = Try {
    val conf =
      ConfigFactory.load(ConfigParseOptions.defaults().setAllowMissing(false))

    val config = conf.getConfig(emailDestinations)
    val emails = config.root.keySet.asScala
      .map(key => key -> config.getStringList(key).asScala)
      .toMap
    Configuration.apply(
      conf.getString(cluster),
      conf.getString(anomalies_descriptions),

      conf.getString(ifrs9_cli_mor_origin_table),
      conf.getString(ifrs9_cli_mor_exec_limit),

      conf.getString(ifrs9_cli_mor_anomalies_table),

      conf.getString(emailProvider),
      emails,
      conf.getString(emailSecurityProvider),
      conf.getString(emailSecurityGrantType),
      conf.getString(emailSecurityClientId),
      conf.getString(emailSecurityClientSecret),
      conf.getString(smsProvider),
      conf.getStringList(smsDestinations).asScala
    )
  }
}

case class Configuration(cluster: String,
                         anomalies_descriptions: String,

                         ifrs9_cli_mor_origin_table: String,
                         ifrs9_cli_mor_exec_limit: String,

                         ifrs9_cli_mor_anomalies_table: String,

                         emailProvider: String,
                         emailDestinations: Map[String, Iterable[String]],
                         emailSecurityProvider: String,
                         emailSecurityGrantType: String,
                         emailSecurityClientId: String,
                         emailSecurityClientSecret: String,
                         smsProvider: String,
                         smsDestinations: Iterable[String])




 */