package com.santander.audit.util

import java.time.LocalDate

//import com.santander.audit.configuration.Configuration
import com.santander.util.alert.notification.{EmailBuilder, SmsBuilder}
import com.santander.util.alert.security.SecurityService
import com.santander.util.alert.security.oauth.OAuthRequest
import com.santander.util.alert.{EmailService, SmsService}
import com.typesafe.scalalogging.LazyLogging
import io.circe.Json
import io.circe.parser.parse

object Notification extends LazyLogging {
/*  def notify(configuration: Configuration, alertType: String, anomaliesAgg: String)(
    subject: String): Unit = {
    /*val report = parse(anomaliesAgg).fold(
      parsingFailure => "Anomalias não detetadas.",
      report => {
        if (report.asArray.getOrElse(Vector.empty).isEmpty)
          "Anomalias não detetadas."
        else s"Anomalias detetadas:\n${report.spaces2}"
      }
    )*/
    val report = anomaliesAgg
    logger.info(">>>Email:\n" + report)

    val securityService = SecurityService.apply(
      configuration.emailSecurityProvider,
      OAuthRequest.apply(configuration.emailSecurityGrantType,
        configuration.emailSecurityClientId,
        configuration.emailSecurityClientSecret)
    )

    val email = EmailBuilder.apply(
      configuration.emailDestinations(alertType.replace(" ","_")).toSeq,
      s"Relatório auditoria - $subject",
      report.replaceAll("\n", "<br>"))
    val emailService =
      EmailService.apply(securityService)(configuration.emailProvider)
    emailService.send(email)
    val smsList = configuration.smsDestinations.map(SmsBuilder.apply(_, report))
    val smsService =
      SmsService.apply(securityService)(configuration.smsProvider)
    smsList.foreach(smsService.send)
  }

*/
  //  def messageFormat(rawJsonArray: String,formatJsonFunction:(scala.Iterable[Json])=>String): String = {
  //
  //    parse(rawJsonArray) match {
  //      case Left(failure) => {
  //        //empty json so no warnings...
  //        "Anomalias não detetadas"
  //      }
  //      case Right(json) => {
  //        //there are warnings need to show them:
  //        if (json.asArray.getOrElse(Vector.empty).isEmpty || json=="[]") {
  //          "Anomalias não detetadas"
  //        } else {
  //          val cursor = json.hcursor
  //          val x = cursor.values.get
  //          var out_string = ""
  //          out_string += "\n-------Email/SMS---------\n"
  //          x.foreach(el => {
  //
  //            out_string += s"\ndia: ${el.hcursor.downField("data_date_part").as[String].fold(fail => "Empty", value => value)}\n"
  //            out_string += s"tipo: ${el.hcursor.downField("type").as[String].fold(fail => "Empty", value => value)}\n"
  //            out_string += s"descrição: ${el.hcursor.downField("description").as[String].fold(fail => "Empty", value => value)}\n"
  //            out_string += s"número de alertas: ${el.hcursor.downField("count").as[Int].fold(fail => 0, value => value)}\n"
  //            out_string += "\n---------------------\n"
  //          })
  //          out_string += "\n-------Email/SMS---------\n"
  //          out_string
  //        }
  //
  //      }
  //    }
  //
  //
  //  }
  def messageFormat(rawJsonArray: String, channel: String): Unit = {
    println(s"Channel $channel")
    println(s"rawJsonArray $rawJsonArray")

    parse(rawJsonArray) match {
      case Left(failure) => {
        //empty json so no warnings...
        s"Anomalias não detetadas"
      }
        print("parse fail")       //<-------
      case Right(json) => {
        //there are warnings need to show them:
        if (json.asArray.getOrElse(Vector.empty).isEmpty || json == "[]") {
          s"Anomalias não detetadas"
        } else {
          val cursor = json.hcursor
          val x = cursor.values.get

          println(s"Parse works")
          channel match {
            case "terminal financeiro" => jsonToHuman(x,"type","description",false)
            //case "norkom" => jsonToHuman(x)
            case _ => jsonToHuman(x)
          }

        }
      }
    }
  }

  def jsonToHuman(json_data: scala.Iterable[Json], type_string: String = "anomaly_type", description: String = "anomaly_description",type_int:Boolean = true): String = {
    var out_string = ""

    out_string += "<style> table, td, th { border: 1px solid black; } </style>"

    out_string += "<table border=\"1\">"
    out_string += "<tr><td width=283 colspan=2 style=\"text-align:center\" style='width:233.75pt;padding:0cm 5.4pt 0cm 5.4pt'>Evento</td>"
    out_string += "<td width=274 rowspan=2 style=\"text-align:center\" style='width:233.75pt;border-left:none;padding:0cm 5.4pt 0cm 5.4pt'>Ocorrências</td>"
    out_string += "<td style=\"text-align:center\" width=274 rowspan=2 >Dia</td></tr>"

    out_string += "<tr><td width=44 style=\"text-align:center\" style='width:28.5pt;border-top:none;padding:0cm 5.4pt 0cm 5.4pt'>Type</td><td width=44 valign=top style='width:28.5pt;border-top:none;padding:0cm 5.4pt 0cm 5.4pt'>Descrição</td></tr>"

    json_data.foreach(el => {
      out_string += "<tr>"
      if(type_int){
        out_string += s"""<td style="text-align:center" >${el.hcursor.downField(type_string).as[Int].fold(fail => "Empty", value => value)}</td>"""
      }else{
        out_string +=
          s"""<td style="text-align:center" >${el.hcursor.downField(type_string).as[String].fold(fail => "Empty", value => value)}</td>"""
      }
      out_string += s"""<td style="text-align:center" >${el.hcursor.downField(description).as[String].fold(fail => "Empty", value => value)}</td>"""
      out_string += s"""<td style="text-align:center" >${el.hcursor.downField("count").as[Int].fold(fail => 0, value => value)}</td>"""

      out_string += s"""<td style="text-align:center" >${el.hcursor.downField("data_date_part").as[String].fold(fail => "Empty", value => value)}</td>"""

      out_string += "</tr>"
    })
    out_string += "</table>"

    out_string += "\nMais detalhe pode ser consultado em http://huetotta.totta.gs.corp:8888/hue/accounts/login/?next=/hue/.\n" +
      "Para mais detalhe de cada anomalia consulte a tabela anomalies_descriptions\n"

    out_string
  }


}
