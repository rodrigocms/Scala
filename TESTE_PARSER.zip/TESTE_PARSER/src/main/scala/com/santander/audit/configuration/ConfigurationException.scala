/* package com.santander.audit.configuration

case class ConfigurationException(message: String,
                                  implicit val reason: Throwable =
                                    new RuntimeException)
    extends Exception(message, reason)


 */