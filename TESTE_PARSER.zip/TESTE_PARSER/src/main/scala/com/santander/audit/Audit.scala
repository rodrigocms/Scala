package com.santander.audit

//import com.santander.audit.logic.Logic.{getConfiguration, init, getDifferentPartitions, getTableIFRS9_CLI_MOR,
//  insertIntoTable, makeReport}
import com.santander.audit.util.Notification
import com.typesafe.scalalogging.LazyLogging

import scala.language.postfixOps

object Audit extends LazyLogging {

  def main(args: Array[String]): Unit = {

    //Read configurations-------

    val dia = java.time.LocalDate.now.toString

   // val configuration = getConfiguration()

   // init()

    //-----------------------------IFRS9_CLI_MOR-----------------------------
    //val analysisPeriod_ifrs9_cli_mor = getDifferentPartitions(configuration.ifrs9_cli_mor_origin_table,
    //  configuration.ifrs9_cli_mor_anomalies_table, "data_date_part")
    //val ifrs9_cli_mor = getTableIFRS9_CLI_MOR(analysisPeriod_ifrs9_cli_mor)
    //insertIntoTable(ifrs9_cli_mor, Seq("data_date_part"), configuration.ifrs9_cli_mor_anomalies_table)
    
    //val ifrs9_cli_mor_report = makeReport(ifrs9_cli_mor)

    val ifrs9_cli_mor_report="[{\"data_date_part\":\"2021-06-23\",\"anomaly_type\":14,\"anomaly_description\":\"Alterações fora das horas habituais (entre as 21h00 e as 7h00)\",\"count\":1}] "
    /// <----- temp para teste

    val report = Notification.messageFormat(channel="ifrs9_cli_mor", rawJsonArray= ifrs9_cli_mor_report)

    //Notification.notify(configuration, "ifrs9_cli_mor", report)(s"${"ifrs9_cli_mor".toUpperCase} - ${configuration.cluster} - ${dia}")
  }

}

